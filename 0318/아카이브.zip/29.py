sum = 0
for i in range (1,6):
    print(i)
    sum += i
print('합 ==', i)